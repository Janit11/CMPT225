#pragma once
#include<stdexcept>
using namespace std;

//Node class
template <class T>
class NodeT
{
public:
    
    //attributes
    T data;
    NodeT<T> * next;
    
    //constructors
    NodeT(T val, NodeT<T> * nxt): data(val), next(nxt){};
    NodeT(T val): data(val), next (nullptr){};
};

// Queue class implemented with a singly linked list.
// Front and back are both nodes and contain data.
template <class T>
class QueueT
{
public:
    
    //constructors, destructor and overloaded operator
    QueueT();
    QueueT(const QueueT& qt);// copy constructor
    ~QueueT();
    QueueT<T>& operator= (const QueueT<T> qt);
    
    //mutators
    //PARAM: T type parameter to be inserted.
    //POST: inserts the value at the back queue.
    void enqueue(T val);
    //POST: removes and returns the value at the front of the queue.
    T dequeue ();
    
    //POST: prints the contents of the queue.
    void print() const;
    //POST: returns true if the queue is empty, false otherwise.
    bool empty();
    //POST: returns the number of items stored in the queue;
    int size() const;
    
    //PARAM: all values of Queue to be added at the end of the calling object and n is how many should be added.
    //POST: increases the size of calling object by n and removes all the values from the queue parameter and adjusts the size.
    void concatenate(QueueT & qt, int n);
    
    //PARAM: values of the Queue should be merged in the calling object.
    //POST: returns the resulting queue which contains merged contents from queue parameter.
    QueueT<T> merge(const QueueT & qt);
    
    //accessor
    //POST: gets the front pointer
    NodeT<T> * getFront() const;
    
private:
    NodeT<T> * front;// front pointer
    NodeT<T> * back;// back pointer
    int sz;// current size of the queue
    
    //helper methods
    void copyQueue(const QueueT<T> &qt);
    void removeAll();
};

//Implementations of QueueT member functions.
template<class T>
QueueT<T>::QueueT() //sets front, back pointer to null and size to 0.
{
    front = nullptr;
    back = nullptr;
    sz=0;
}

template<class T>
QueueT<T>::QueueT(const QueueT &qt) //copies the elements of parameter to calling object.
{
    copyQueue(qt);
}

template<class T>
QueueT<T>::~QueueT() //removes all the elements from the Queue.
{
    removeAll();
}

template<class T>
QueueT<T>& QueueT<T>::operator=(const QueueT<T> qt) //assigns the values of qt to calling object
{
    if (this!= &qt){
        removeAll();
        copyQueue(qt);
    }
    return *this;
}

template<class T>
void QueueT<T>::enqueue(T val) //inserts the item at the back.
{
    if(front == nullptr){
        front = new NodeT<T>(val, nullptr);
        back = front;
        sz++;
    }
    else{
        NodeT<T> * temp= back;
        temp->next = new NodeT<T>(val,nullptr);
        back = temp->next;
        sz++;
    }
}

template<class T>
T QueueT<T>:: dequeue() //removes the item from the front.
{
    if(front == nullptr){
        throw std::runtime_error("Cannot remove item - queue empty");
    }
    else{
        NodeT<T> * temp = front;
        T value;
        front = temp->next;
        value = temp->data;
        delete temp;
        sz--;
        return value;
    }
}

template<class T>
void QueueT<T>:: print() const //prints the data of the queue one by one.
{
    NodeT<T> * p= front;
    while(p!= nullptr){
        cout<<p->data<<" ";
        p=p->next;
    }
}

template <class T>
bool QueueT<T>::empty() //checks if the queue is empty.
{
    if(sz==0)
        return true;
    return false;
}

template <class T>
int QueueT<T>::size() const // returns the size of the queue.
{
    return sz;
}

//PARAM: all values of Queue to be added at the end of the calling object and n is how many should be added.
//POST: increases the size of calling object by n and removes all the values from the queue parameter and adjusts the size.
template <class T>
void QueueT<T>::concatenate(QueueT & qt, int n)//
{
    if(n> qt.size()){
        throw std::runtime_error("n is greater than the size of qt");
    }
    //n must be positive
    else{
        back->next = qt.getFront();
        NodeT<T> * temp = back;
        for(int i=0; i<n; i++){
            temp = temp->next;
            sz++;
            qt.sz--;
        }
        qt.front= temp->next;
        temp->next= nullptr;
        back = temp;
    }
}

//PARAM: values of the Queue should be merged in the calling object.
//POST: returns the resulting queue which contains merged contents from queue parameter.
template<class T>
QueueT<T> QueueT<T>:: merge(const QueueT<T> &qt)
{
    QueueT q;
    NodeT<T> * temp1= front;
    NodeT<T> * temp2 = qt.front;
    while (temp1 != nullptr || temp2 != nullptr){
        if(temp1 != nullptr && temp2 != nullptr){
            q.enqueue(temp1->data);
            q.enqueue(temp2->data);
            temp1= temp1->next;
            temp2= temp2->next;
        }
        else if(temp1 != nullptr){
            q.enqueue(temp1->data);
            temp1 = temp1->next;
        }
        else{
            q.enqueue(temp2->data);
            temp2 = temp2->next;
        }
    }
        
    return q;
}
template<class T>
NodeT<T>* QueueT<T>::getFront() const //returns the front of the queue.
{
    return front;
}


//helper methods

template<class T>
void QueueT<T>::copyQueue(const QueueT<T> &qt) // copies all the elements in the calling object
{
    front = nullptr;
    back = nullptr;
    sz = 0;
    
    if(qt.front!=nullptr){
        NodeT<T> * original = qt.front;
        sz= qt.sz;
        
        NodeT<T> * temp = new NodeT<T>(original->data, nullptr);
        front = temp;
        original= original->next;
        while(original!=nullptr){
            temp->next = new NodeT<T>(original->data, nullptr);
            temp = temp->next;
            original = original->next;
        }
        back = temp;
    }
}

template<class T>
void QueueT<T>:: removeAll() //removes the all the elements from the queue.
{
    NodeT<T> * temp = front;
    while (front!= nullptr){
        front = temp->next;
        delete temp;
        temp = front;
    }
    front = nullptr;
}

