#pragma once
#include<stdexcept>
#include<vector>
using namespace std;

//Question1
// PARAM: arr is array to print the Cartesian product of, n is size of arr
int cartesianProduct(int arr[], int n)
{
    int count=0;
    int i = 0;
    count++;
       while (i < n) {
           int j = 0;
           while (j < n) {
               cout << "{" << arr[i] << "," << arr[j] << "}";
               j++;
               cout << " ";
               count = count + 4;
           }
           cout << endl;
           i++;
           count+=5;
       }
    count++;
    return count;
}


//Question2
int triangle(int x)
{
    int count=0;
    int i = 0;
    count++;
    while (i < x) {
        int j = 0;
        while (j <= i) {
            cout << j << " ";
            j++;
            count+=3;
        }
        cout << endl;
        i++;
        count+=5;
    }
    count++;
    while (i > 0) {
        i--;
        int j = 0;
        while (j <= i) {
            cout << j << " ";
            j++;
            count+=3;
        }
        cout << endl;
        count+=5;
    }
    count++;
    return count;
}


//Question3
// PARAM: arr is array from which duplicates are to be removed, n is size of arr
vector<int> removeDuplicates(int arr[], int n, int &ops_count)
{
    vector<int> result;
    int i = 0;
    ops_count+=2;
    while (i < n) {
        int iResult = 0;
        bool duplicate = false;

        while (iResult < (int)result.size() && !duplicate) { //note 4
            if (arr[i] == result[iResult]) {
                duplicate = true;
            }

            iResult++;
            ops_count+=4;
        }
        ops_count+=4;
        if (!duplicate) {
            result.push_back(arr[i]);//note 4
        }
        i++;
        ops_count+=2;
    }
    ops_count++;
    return result;
}



//Question4
// Returns the index of a 1d array representing a matrix
// given row (r) and column (c) values
int rcIndex(int r, int c, int columns)
{
    return r * columns + c;
}
// PRE: m represents a square matrix of size rows * rows
// PARAM: rows represents the number of both rows and columns
// POST: Returns a pointer to an array (matrix) of the same size as m
// NOTE: values are indexed r0c0,r0c1,…,r0cn-1,r1c0,…
int* matrixSelfMultiply(int* m, int rows, int &ops_count)
{
       // Create result array
    int columns = rows;
    int* result = new int[rows * columns];
    int r = 0;
    ops_count+=3;
    while (r < rows) {
        int c = 0;
        while (c < columns) { //columns = rows
            int next = 0;
            int iNext = 0;

            while (iNext < rows) {
                next += m[rcIndex(r, iNext, columns)] * m[rcIndex(iNext, c, columns)];
                iNext++;
                ops_count+=3;
            }

            result[rcIndex(r, c, columns)] = next;
            c++;
            ops_count+=6;
        }
        r++;
        ops_count+=4;
    }
    ops_count++;
    return result;
}


//Question5
// PARAM: arr is array to be sorted, n is size of array, i should initially = 0
int ssort(int arr[], int n, int i)
{
    int count=0;
    count++;
    if (i < n-1) {
        // Find and swap smallest remaining
        int next = i + 1;
        int smallest = i;
        count+=2;
        while (next < n) {
            if (arr[next] < arr[smallest]) {
                smallest = next;
            }
            next++;
            count+=4;
        }
        count++;
        // Swap i with smallest
        int temp = arr[i];
        arr[i] = arr[smallest];
        arr[smallest] = temp;
        count+=3;
        count+=ssort(arr, n, i + 1);
    }
    return count;
}


//Question6
// PRE: n is a power of 2 greater than zero.
// PRE: Initial call should be to i = 0
// e.g. pattern(8, 0)
int pattern(int n, int i)
{
    int count=0;
    count++;
    if (n > 0) {
        count+=pattern(n/2, i);
        // Print i spaces
        cout << string(i, ' '); // NOTE: counts as ONE operation

        // A loop to print n asterisks, each one followed by a space
        int ast = 0;
        while (ast < n) {
            cout << "* ";
            ast++;
            count+=3;
        }
        count+=3;
        cout << endl;
        i += n;
        count+=2;
        count+=pattern(n / 2, i);
    }
    return count;
}
