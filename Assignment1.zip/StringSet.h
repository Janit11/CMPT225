#pragma once
#include <string>
using std::string;

class StringSet
{
public:
    // default constructor
    //PRE: Array of string empty.
    //POST: Sets the maxsize of the array to 2.
    StringSet();

    // copy constructor
    //PRE: StringSet in scope.
    //PARAM: sSet to be copied in the calling object.
    //POST: Copies the elements of sSet in the calling object.
    StringSet(const StringSet & sSet);

    //destructor
    //PRE: StringSet exists.
    //POST: Deallocates the dynamic memory associated with object's array pointer.
    ~ StringSet();

    //PRE: StringSet exists.
    //PARAM: sSet to be assigned to the calling object.
    //POST: Copies the elements of sSet in the calling object.
    StringSet& operator = (const StringSet & sSet);

    //PRE: String object as parameter.
    //PARAM: String parameter to be inserted in the array.
    //POST: Inserts value if not found in array otherwise return false
    bool insert(string str);

    //PRE: String object as parameter.
    //PARAM: String parameter to be removed from the array.
    //POST: Replaces matching string with last string and decrement in size.
    void remove(string str);

    //PRE: String object in scope.
    //PARAM: Find string parameter in the array.
    //POST: Returns the index if string is found in the array.
    int find(string str);
    
    //PRE: This size of the array <= maxsize.
    //POST: Returns the size
    int size() const;

    //PRE: sSet exists.
    //PARAM: sSet param not to be changed.
    //POST: Returns a union set.
    StringSet unions(const StringSet & sSet);
    
    //PRE: sSet exists.
    //PARAM: constant sSet param.
    //POST: Returns an intersection set.
    StringSet intersection(const StringSet & sSet);

    //PRE: sSet exists.
    //PARAM: Elements of sSet to be removed from the calling object's elements.
    //POST: Returns a difference set.
    StringSet difference(const StringSet & sSet);


private:

    std::string* A;
    
    int arrsize; // size of the array i.e. number of elements present in it.

    int maxsize; // max size of the array.
    
    void copyStringSet(const StringSet & sSet); //Deep copies the sSet to the calling object.

    string getstr(int i) const;
};
