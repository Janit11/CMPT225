#include "StringSet.h"


// default constructor
//PRE: Array of string empty.
//POST: Sets the maxsize of the array to 2.
StringSet::StringSet()
{
    maxsize=2;
    A= new string[maxsize];
    arrsize=0;
    
}

// copy constructor
//PRE: StringSet in scope.
//PARAM: sSet to be copied in the calling object.
//POST: Copies the elements of sSet in the calling object.
StringSet::StringSet(const StringSet & sSet)
{
    copyStringSet(sSet);
}

void StringSet::copyStringSet(const StringSet & sSet)
{
    maxsize= sSet.maxsize;
    arrsize= sSet.arrsize;
    
    A = new string[maxsize];
    for(int i=0; i<arrsize; i++)
    {
        A[i]= sSet.A[i];
    }
}

//destructor
//PRE: StringSet exists.
//POST: Deallocates the dynamic memory associated with object's array pointer.
StringSet::~StringSet()
{
    delete [] A;
}

//PRE: StringSet exists.
//PARAM: sSet to be assigned to the calling object.
//POST: Copies the elements of sSet in the calling object.
StringSet& StringSet:: operator =(const StringSet & sSet)
{
    if(this != &sSet)
    {
        this->~StringSet();
        copyStringSet(sSet);
    }
    return *this;
}

//PRE: String object as parameter.
//PARAM: String parameter to be inserted in the array.
//POST: Inserts value if not found in array otherwise return false.
bool StringSet::insert(string str)
{
    for(int i=0; i<arrsize; i++)
    {
        if(str==A[i])
        {
            return false;
        }
    }
    if(arrsize>=maxsize)
    {
        string * temp = new string [maxsize];
        
        for(int i=0; i<arrsize; i++)
            temp[i]=A[i];
        
        maxsize += maxsize;
        A= new string[maxsize];
        
        for(int i=0; i<arrsize; i++)
            A[i]= temp[i];
        
        delete [] temp;
    }
    A[arrsize] = str;
    arrsize++;
    return true;
}

//PRE: String object as parameter.
//PARAM: String parameter to be removed from the array.
//POST: Replaces matching string with last string and decrement in size.
void StringSet::remove(string str)
{
    for(int i=0; i<arrsize; i++)
    {
        if(str== A[i])
        {
            A[i]= A[arrsize-1];
            arrsize--;
        }
    }
}


//PRE: String object in scope.
//PARAM: Find string parameter in the array.
//POST: Returns the index if string is found in the array.
int StringSet::find(string search)
{
    for(int i=0; i<arrsize; i++)
    {
        if(A[i]==search)
            return i;
    }
    return -1;
}

int StringSet::size () const
{
    return arrsize;
}

string StringSet::getstr(int i) const
{
    return A[i];
}

//PRE: sSet exists.
//PARAM: sSet param not to be changed.
//POST: Returns a union set.
StringSet StringSet::unions(const StringSet & sSet)
{
    StringSet unionSet = *this;
    int tempsize= arrsize;
    
    if(arrsize< sSet.arrsize)
    {
        tempsize= sSet.arrsize;
    }
    for(int i=0; i<tempsize; i++)
    {
        string addstr= sSet.getstr(i);
        unionSet.insert(addstr);
    }
    return unionSet;
}

//PRE: sSet exists.
//PARAM: constant sSet param.
//POST: Returns an intersection set.
StringSet StringSet::intersection(const StringSet & sSet)
{
    StringSet intSet;
    int tempsize= arrsize;
    if(arrsize< sSet.arrsize)
    {
        tempsize= sSet.arrsize;
    }
    for(int i=0; i<tempsize; i++)
    {
        string findstr= sSet.getstr(i);
        int commonstr= find(findstr);
        
        if(commonstr!=-1)
        {
            intSet.insert(findstr);
        }
    }
    
    return intSet;
}

//PRE: sSet exists.
//PARAM: Elements of sSet to be removed from the calling object's elements.
//POST: Returns a difference set.
StringSet StringSet:: difference(const StringSet & sSet)
{
    StringSet diffSet = *this;
    for(int i=0; i<sSet.arrsize; i++)
    {
        string findstr= sSet.getstr(i);
        diffSet.remove(findstr);
    }
    return diffSet;
}
