#pragma once
#include<iostream>
#include<string>
#include<stdexcept>
#include<vector>
#include<cmath>
#include<fstream>
#include<stdlib.h>
#include <stdio.h>
using namespace std;

//NodeT class
template<class T>
class NodeT
{
public:
    //attributes
    T data;
    NodeT<T>* left;
    NodeT<T>* right;
    NodeT<T>* parent;
    bool isBlack;
    
    //constructors
    NodeT(T val): data(val), left(nullptr), right(nullptr), parent(nullptr), isBlack(false){};
    NodeT(T val, bool color) : data(val), left(nullptr), right(nullptr), parent(nullptr) ,isBlack(color){};
};

//RedBlackTree class

template<class T>
class RedBlackTree
{
public:
    //constructors, destructor and overloaded operator.
   
    RedBlackTree();
    RedBlackTree(const RedBlackTree& tree); //copy constructor
    RedBlackTree<T>& operator=(const RedBlackTree<T>& tree);
    ~RedBlackTree();
    
    //mutators
    //PRE: new inserted node should be red.
    //PARAM: T type parameter to be inserted
    //POST: returns true is the value is inserted otherwise false.
    bool insert(T val);
    
    //PRE: tree to be fixed if the removed node is black otherwise no need.
    //PARAM: T parameter to be removed.
    //POST: returns true if it is found otherwise false.
    bool remove(T val);
    
    //accessors
    //PRE:
    //PARAM: T parameter to be searched.
    //POST: returns true if it is found.
    bool search(T val);
    
    //PRE: tree is a redblack tree.
    //PARAM: values to be searched from the start parameter to the end parameter.
    //POST: returns a vector containing all the values b/w start and end.
    vector<T> search(T start, T end);
    
    //PRE:
    //PARAM: val less than T paramter to be returned.
    //POST: returns the largest value but less than the parameter if the val is found otherwise return the same value.
    T closestLess(T val) ;
    //PRE:
    //PARAM: smaller val but greater than the T parameter to be returned.
    //POST: returns the smallest value but greater than the parameter if the val is found otherwise return the same value.
    T closestGreater(T val) ;
    
    //PRE: tree should be a redblack tree.
    //PARAM:
    //POST: returns a vector containing all the values of the tree.
    vector<T> values();
    
    //PRE:
    //PARAM:
    //POST: returns the size of the tree.
    int size() const;
    
    //friend functiom
    template <class Tjwme>
    friend NodeT<Tjwme>* JWMEgetRoot(const RedBlackTree<Tjwme> & rbt);

    
private:
    //attributes
    NodeT<T>* root;
    int treeSize;
    
    //helpermethods
    NodeT<T>* copyTree(NodeT<T>* nd);
    void RemoveAll(NodeT<T>* nd);
    NodeT<T>* bstInsert(NodeT<T>* root, NodeT<T>* node);
    void rbFix(NodeT<T>* childnode, NodeT<T>* parentnode);
    void leftRotate(NodeT<T> * node);
    void rightRotate(NodeT<T> * node);
    NodeT<T>* find(NodeT<T>* nd, T val);
    NodeT<T>* predecessor(NodeT<T>* node) const;
    void findRange(NodeT<T>* ptr, vector<T> &v,int small, int large);
    void valuesInserter(NodeT<T>* ptr, vector<T> &v);
    int sizeHelper(NodeT<T> * nd) const;

};

//sets the root to null.
template<class T>
RedBlackTree<T>:: RedBlackTree()
{
    root= nullptr;
}

//creates a deep copy of the parameter's elements into the calling object.
template<class T>
RedBlackTree<T>:: RedBlackTree(const RedBlackTree& tree)
{
    if(tree.root==nullptr){
        root= nullptr;
    }else{
        treeSize = tree.size();
        root= copyTree(tree.root);
    }
}

//copies all the element of a tree to another tree.
template<class T>
NodeT<T>* RedBlackTree<T>::copyTree(NodeT<T>* nd)
{
    if(nd==nullptr){
        return nd;
    }
    
    NodeT<T>* node = new NodeT<T>(nd->data, nd->isBlack);
    node->left= copyTree(nd->left);
    node->right=copyTree(nd->right);
    if(nd->left!=nullptr){
        node->left->parent= node;
    }
    if(nd->right!=nullptr){
        node->right->parent= node;
    }
    return node;
}

//assigns the values of the tree to the calling object.
template<class T>
RedBlackTree<T>& RedBlackTree<T>::operator=(const RedBlackTree<T>& tree)
{
    if(this!= &tree){
        RemoveAll();
        treeSize = tree.size();
        copyTree(tree.root);
    }
    return *this;
}

//deletes the tree
template<class T>
RedBlackTree<T>::~RedBlackTree()
{
    RemoveAll(root);
}

//deletes all the nodes from the tree
template<class T>
void RedBlackTree<T>::RemoveAll(NodeT<T>* nd)
{
    if(nd==nullptr){
        return;
    }
    RemoveAll(nd->left);
    delete nd;
    RemoveAll(nd->right);
}

//returns true is the value is inserted otherwise false.
template<class T>
bool RedBlackTree<T>::insert(T val)
{
    if(search(val)){
        return false;
    }
    
    NodeT<T>* newNode= new NodeT<T>(val);
    root= bstInsert(root, newNode); // inserts value in tree .
    //now we need to fix the tree so that the black height rule is not violated.
    newNode->isBlack = false;
    while(newNode!=root && !newNode->parent->isBlack){
        if(newNode->parent== newNode->parent->parent->left){ //checking if newNode's parent is a left child.
            NodeT<T>* uncle= newNode->parent->parent->right; //newNode's uncle
            if(!uncle->isBlack){
                newNode->parent->isBlack = true;
                uncle->isBlack = true;
                newNode->parent->parent->isBlack = false;
                newNode = newNode->parent->parent;
            }else{ // uncle is black or is null
                if(newNode == newNode->parent->right){
                    newNode = newNode->parent;
                    leftRotate(newNode);
                }
                newNode->parent->isBlack = true;
                newNode->parent->parent->isBlack = false;
                rightRotate(newNode->parent->parent);
            }
        }else{ // if newNode's parent is a right child
            NodeT<T>* uncle = newNode->parent->parent->left;
            if(uncle != nullptr && !uncle->isBlack){
                newNode->parent->isBlack = true;
                uncle->isBlack = true;
                newNode->parent->parent->isBlack = false;
                newNode = newNode->parent->parent;
            }else{// if uncle's black or null
                if(newNode == newNode->parent->left){
                    newNode = newNode->parent;
                    rightRotate(newNode);
                }
                newNode->parent->isBlack = true;
                newNode->parent->parent->isBlack = false;
                leftRotate(newNode->parent->parent);
            }
        }
    }
    root->isBlack = true; // set root's colour to black
    return true;
}

// inserts the new node in a binary search tree.
template<class T>
NodeT<T>* RedBlackTree<T>:: bstInsert(NodeT<T>* root, NodeT<T>* node)
{
    if(root==nullptr){
        return node;
    }
    //if the node's value is lesser than the root's value, add the node in the left subtree.
    if(root->data> node->data){
        root->left= bstInsert(root->left, node);
        root->left->parent= root;
    }
    // otherwise add in the right subtree.
    if(root->data< node->data){
        root->right= bstInsert(root->right, node);
        root->right->parent= root;
    }
    return root;
}

//returns true if it is found otherwise false.
template<class T>
bool RedBlackTree<T>::remove(T val)
{
    if(root==nullptr || !find(root,val)){
        return false;
    }
    NodeT<T>* nd = find(root, val);
    if(nd== root && nd->left== nullptr && nd->right== nullptr){
        delete nd;
        root = nullptr;
        return true;
    }
    
    NodeT<T>* removeptr = nullptr;
    if(nd->left== nullptr||nd->right== nullptr){ // if the node has no or one child
        removeptr = nd;
    }else{
        removeptr = predecessor(nd);
    }
    
    NodeT<T>* child = nullptr;
    if(removeptr->left != nullptr){
        child = removeptr->left;
    }else{
        child = removeptr->right;
    }
    
    if(child!= nullptr){
        child->parent = removeptr->parent; //detaching child.
    }
    
    if(removeptr->parent == nullptr){
        root = child;
    }else{
        if(removeptr==removeptr->parent->left)
            removeptr->parent->left = child;
        else{
            removeptr->parent->right = child;
        }
    }
    
    if(removeptr!= nd){
        nd->data = removeptr->data;
    }
    
    if(removeptr->isBlack){
        rbFix(child, removeptr->parent);
    }
    delete removeptr;
    return true;
}

//fixes the tree to adjust the black height.
template<class T>
void RedBlackTree<T>::rbFix(NodeT<T>* child, NodeT<T>* parentnd)
{
    while(child!= root && (child== nullptr||child->isBlack==true)){
        if(child == child->parent->left){ // if child is a left child
            NodeT<T>* sibling = child->parent->right; // child's sibling
            if(!sibling->isBlack){ //is sibling is red
                sibling->isBlack = true;
                parentnd->isBlack = false; // this must be black since sibling was red- change to red.
                leftRotate(child->parent);
                sibling = parentnd->right;
            }
            if((sibling->left == nullptr || sibling->left->isBlack==true)&& (sibling->right == nullptr || sibling->right->isBlack==true)){ // if sibling's both the children are either null or are both black.
                sibling->isBlack = false;
                child = parentnd;
            }else{
                if(sibling->right->isBlack){
                    sibling->left->isBlack = true;
                    sibling->isBlack = false;
                    rightRotate(sibling);
                    sibling = parentnd->right;
                }
                sibling->isBlack = parentnd->isBlack;
                parentnd->isBlack = true;
                sibling->right->isBlack = true;
                leftRotate(child->parent);
                child = root;
            }
        }else{
            NodeT<T>* sibling = child->parent->left; // child's sibling
            if(!sibling->isBlack){ //is sibling is red
                sibling->isBlack = true;
                parentnd->isBlack = false; // this must be black since sibling was red- change to red.
                rightRotate(child->parent);
                sibling = parentnd->right;
            }
            if((sibling->left == nullptr || sibling->left->isBlack==true)&& (sibling->right == nullptr || sibling->right->isBlack==true)){ // if sibling's both the children are either null or are both black.
                sibling->isBlack = false;
                child = parentnd;
            }else{
                if(sibling->right->isBlack){
                    sibling->left->isBlack = true;
                    sibling->isBlack = false;
                    leftRotate(sibling);
                    sibling = parentnd->right;
                }
                sibling->isBlack = parentnd->isBlack;
                parentnd->isBlack = true;
                sibling->right->isBlack = true;
                rightRotate(child->parent);
                child = root;
            }
        }
    }
    child->isBlack = true;
}

//finds the parameter val in the tree
template<class T>
NodeT<T>* RedBlackTree<T>::find(NodeT<T>* nd, T val)
{
    if(nd == nullptr){
        return nullptr;
    }
    if(val< nd->data){
        return find(nd->left, val);
    }
    if(val== nd->data){
        return nd;
    }
    else{
        return find(nd->right, val);
    }
}

// returns the leftest node to the parameter.
template<class T>
NodeT<T>* RedBlackTree<T>:: predecessor(NodeT<T>* node) const
{
    NodeT<T>* nd = node;
    while(nd->right!=nullptr){
        nd = nd->right;
    }
    return nd;
}

// left rotates the tree to fix the colour of the nodes
template<class T>
void RedBlackTree<T>:: leftRotate(NodeT<T> * node)
{
    NodeT<T>* temp = node->right;
    node->right = temp->left;
    
    if(node->right!= nullptr){ // to check if temp has a child or not
        temp->left->parent = node; // if yes we assign temp to node
    }
    
    temp->parent = node->parent;
    if(node->parent == nullptr){
        root= temp;
    }
    else if(node == node->parent->left){
        node->parent->left = temp;
    }
    else{ //node == node->parent->right
        node->parent->right = temp;
    }
    temp->left = node;
    node->parent = temp;
}

//right rotates the tree to fix the colour of the nodes
template<class T>
void RedBlackTree<T>:: rightRotate(NodeT<T> * node)
{
    NodeT<T>* temp = node->left;
    node->left = temp->right;
    
    if(node->left != nullptr){
        temp->right->parent = node;
    }
    
    temp->parent = node->parent;
    if(node->parent == nullptr){
        root = temp;
    }
    else if(node == node->parent->left){
        node->parent->left = temp;
    }
    else{//node == node->parent->right
        node->parent->right = temp;
    }
    temp->right = node;
    node->parent = temp;
}

//returns true if it is found.
template<class T>
bool RedBlackTree<T>::search(T val)
{
    NodeT<T>* nd = find(root, val);
    if(root==nullptr){
        return false;
    }
    if(!nd){
        return false;
    }
    return true;
}
//returns a vector containing all the values b/w start and end.
template<class T>
vector<T> RedBlackTree<T>:: search(T start, T end)
{
    vector<T> v;
    findRange(root, v, start, end);
    return v;
    
}

//finds all the values between small and large.
template<class T>
void RedBlackTree<T>::findRange(NodeT<T>* nd, vector<T> &v,int small, int large){
    
    if(nd != nullptr)
    {
        findRange(nd->left,v, small, large);
        if(nd->data >= small && nd->data <= large)
        {
            v.push_back(nd->data);
        }
        findRange(nd->right,v, small, large);
    }
}

//returns the largest value but less than the parameter if the val is found otherwise return the same value.
template<class T>
T RedBlackTree<T>::closestLess(T val)
{
    NodeT<T>* nd = root;
    T difference = abs(val-nd->data), temp, closestval = nd->data;
    if(!find(nd,val)){
        return val;
    }
    if(nd== nullptr){
        return closestval;
    }
    while(nd!=nullptr){
        if(val<nd->data){
            nd= nd->left;
            if(nd!=nullptr){
                temp = abs(val-nd->data);
                if(difference>=temp){
                    difference = temp;
                    closestval= nd->data;
            }
           
            }
        }else{
            nd = nd->right;
            if(nd!=nullptr){
                temp = abs(val-nd->data);
                if(temp>=difference ){
                    difference = temp;
                    closestval= nd->data;
                }
            }else{
                return closestval;
            }
        }
        if( val == nd->data ){
            if(nd->left!=nullptr){
                nd = nd->left;
                temp = abs(val-nd->data);
                if(temp>difference){
                    difference = temp;
                    closestval= nd->data;
                }
            }else{
                return closestval;
            }
        }
        
    }
    return closestval;
}

//returns the smallest value but greater than the parameter if the val is found otherwise return the same value.
template<class T>
T RedBlackTree<T>::closestGreater(T val)
{
    NodeT<T>* nd = root;
    T difference = abs(val-nd->data), temp, closestval = nd->data;
    if(!find(nd,val)){
        return val;
    }
    if(nd== nullptr){
        return closestval;
    }
    while(nd!=nullptr){
        if(val<nd->data){
            nd= nd->left;
            if(nd!=nullptr){
                temp = abs(val-nd->data);
                if(difference<=temp){
                    difference = temp;
                    closestval= nd->data;
                }
            }

        }else{
            nd = nd->right;
            if(nd!=nullptr){
                temp = abs(val-nd->data);
                if(temp<=difference ){
                    difference = temp;
                    closestval= nd->data;
                }
            }else{
                return closestval;
            }
        }
        if( nd!=nullptr && val == nd->data ){
            if(nd->right!=nullptr){
                nd = nd->right;
                temp = abs(val-nd->data);
                if(temp>difference){
                    difference = temp;
                    closestval = nd->data;
                }
            }else{
                return closestval;
            }
        }

    }
    return closestval;
    
}

//returns a vector containing all the values of the tree.
template<class T>
vector<T> RedBlackTree<T>:: values()
{
    vector<T> v;
    valuesInserter(root, v);
    return v;
    
}

//inserts the values in a vector.
template<class T>
void RedBlackTree<T>::valuesInserter(NodeT<T>* ptr, vector<T> &v){
    if(root==nullptr){
        return;
    }
    if(ptr->left != nullptr)
        valuesInserter(ptr->left, v);
    v.push_back(ptr->data);
    if(ptr->right != nullptr)
        valuesInserter(ptr->right, v);
}

//returns the size of the tree
template<class T>
int RedBlackTree<T>:: size() const
{
    int count =0;
    if(root!=nullptr){
        count =sizeHelper(root);
    }
    return count;
    
}

//helper method for size function.
template<class T>
int RedBlackTree<T>:: sizeHelper(NodeT<T> * nd) const
{
    int a=1;
    if(nd==nullptr){
        return 0;
    }
    if(nd->left!=nullptr){
        a+= sizeHelper(nd->left);
    }
    if(nd->right!=nullptr){
        a+= sizeHelper(nd->right);
    }
    return a;
}







//Part 2
//returns the number of uniques values.
int uniqueValues(RedBlackTree<double> tree)
{
    int count = 1;
    vector<double> all_values;
    all_values = tree.values();
    for(int i=1; i<all_values.size(); i++){
        int j=0;
        for(j=0; j<i; j++){
            if(all_values.at(i)==all_values.at(j)){
                break;
            }
        }
        if(i==j){
            count++;
        }
    }
    return count;
}

//returns the average of the values.
double getAverage(RedBlackTree<double> tree)
{
    vector<double> all_values;
    all_values = tree.values();
    double sum=0;
    for(int i=0; i<all_values.size() ; i++) {
        sum = sum + all_values.at(i);
    }
    return sum/all_values.size();
}

//returns the median of the values
double getMedian(RedBlackTree<double> tree)
{
    vector<double> all_values;
    all_values = tree.values();
        
    cout<<endl;
    if (all_values.size() % 2 == 0)
        return (all_values.at(all_values.size()/2 - 1) + all_values.at(all_values.size()/2)) / 2;
    else
        return all_values.at(all_values.size() / 2);
}

//helper method for ClosestLess
int findIndex(vector<double> v,double num)
{
    int index=0;
    bool flag = false;
    
    for(int i =0; i<v.size(); i++){
        if(v.at(i)<num){
            flag = true;
            break;
        }
    }
    if(flag==false){
        cout<<"No value less than "<< num <<"exists"<<endl;
        return -1;
    }
    double diff_value = num - v.at(0);
    for(int i =1; i<v.size(); i++){
        if(v.at(i) >= num)
            return index;
        if ( (num-v.at(i)) < diff_value) {
            diff_value=num-v.at(i);
            index = i;
        }
    }
    return index;
}

//returns a value less than 42.
double ClosestLess(RedBlackTree<double> &tree,double num)
{
    vector<double> all_values;
    all_values = tree.values();
    int numIndex =findIndex(all_values, num);
    if(numIndex ==-1){
        tree.~RedBlackTree();
        exit(EXIT_FAILURE);
    }
    return all_values.at(numIndex);
   
}

//helper method for ClosestGreater
int closestGreatHelp(vector<double> v,double num)
{
    int index=0;
    bool flag = false;
    
    for(int i =0; i<v.size(); i++){
        if(v.at(i)>num){
            flag = true;
            index = i;
            break;
        }
    }
    if(flag==false){
        cout<<"No value greater than "<< num <<"exists"<<endl;
        return -1;
    }
    double diff_value = v.at(index)- num;
    for(int i =index +1; i<v.size(); i++){
        if(v.at(i) >= num)
            return index;
        if ((v.at(i)-num) < diff_value) {
            diff_value=v.at(i)-num;
            index = i;
        }
    }
    return index;
}
//returns a value greater than 42.
double ClosestGreater(RedBlackTree<double> &tree,double num)
{
    vector<double> all_values;
    all_values = tree.values();
    int numIndex =closestGreatHelp(all_values, num);

    if(numIndex ==-1){
        tree.~RedBlackTree();
        exit(EXIT_FAILURE);
    }
    return all_values.at(numIndex);
}

//prints the statistics
void statistics( string filename) {
    ifstream fin;
    fin.open(filename);
    
//    if(fin.fail()) {
//        cerr<<"Failed to open file "<<filename<<endl;
//        return;
//    }
 // can be used for debugging not required by assignment
    double num;
    RedBlackTree<double> myData;
    
    while(!fin.eof()) {
        fin>>num;
        myData.insert(num);
    }
    double x=42;
    fin.close(); // closing file here.
    
    cout<<endl<<endl;
    cout<<"printing stats"<<endl;
    // printing stats:
    cout<<"# of values: "<< uniqueValues(myData) << endl;
    cout<<"Average: "<< getAverage(myData)<< endl;
    cout<<"Median: "<< getMedian(myData)  << endl;
    cout<<"Closest < 42 : "<<ClosestLess(myData, x) << endl;
    cout<<"Closest > 42 : "<< ClosestGreater(myData, x) << endl;
}
