#pragma once
#include<iostream>
#include<string>
using namespace std;

class HashTable{
public:
    //constructors, copy constructor and destructor
    HashTable();
    
    //POST: creates a hashtable to store n items.
    HashTable(int Tsize);
    
    //POST: creates a deep copy of its parameter.
    HashTable(const HashTable& hashT);
    
    //POST: de-allocates the dynamic memory.
    ~HashTable();
    
    //POST: overloads the assignment operator for hashtable objects.
    HashTable& operator=(const HashTable& hashT);
    
    //mutator
    //PRE:
    //PARAM: string parameter to be inserted.
    //POST: if the matching string is not found inserts the parameter.
    void insert(string s);
    
    //accessors
    //PRE:
    //PARAM: string s to be found
    //POST: returns true if string parameter is found.
    bool find(string s) const;
    
    //PRE:
    //PARAM:
    //POST: returns the number of items stored in the hashtable.
    int size() const;
    
    //POST: returns the size of the hashtable.
    int maxSize() const;
    
    //POST: returns the load factor of the hashtable.
    double loadFactor() const;
    
private:
    //attributes
    string* hashTable;
    int tSize;//table size
    int secondHashval;
    int currentSize;
    
    //helper methods
    //helper function for copy constructor
    void copyHash(const HashTable& hashT);
    int hashOne(string s) const;
    int hashSecond(string s) const;
    bool checkIfPrime(int n) const;
    int getMyPrime(int n) const;
};
