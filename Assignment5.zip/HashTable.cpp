#include"HashTable.h"
#include"spellcheck.h"
#include<math.h>
#include<iostream>

HashTable::HashTable()
{
    tSize = 101; //size of the hashtable
    currentSize = 0;
    hashTable = new string[tSize]; //creates a hashtable of size 101
    for(int i =0; i<tSize; i++){
        hashTable[i] = "";
    }
    secondHashval = getMyPrime(tSize/2);
}

//creates a hashtable to store n items.
HashTable::HashTable(int n)
{
    tSize = getMyPrime(2*n);
    hashTable = new string[tSize];
    currentSize = 0;
    for(int i =0; i<tSize; i++){
        hashTable[i] = "";
    }
    secondHashval = getMyPrime(tSize/2);
}

//creates a deep copy of its parameter.
HashTable::HashTable(const HashTable& hashT)
{
    copyHash(hashT);
}

//de-allocates the dynamic memory.
HashTable::~HashTable()
{
    tSize = 0;
    currentSize = 0;
    secondHashval = 0;
    delete [] hashTable;
}

//overloads the assignment operator for hashtable objects.
HashTable& HashTable::operator=(const HashTable& hashT){
    if(this !=  &hashT){
        delete [] hashTable;
        copyHash(hashT);
    }
    return *this;
}

//if the matching string is not found inserts the parameter.
void HashTable::insert(string s)
{
    int indexOne = hashOne(s);
    int indexSecond = hashSecond(s);
    
    bool found = find(s);
    if(!found){
        while(hashTable[indexOne] != ""){
            indexOne = (indexOne + indexSecond)% tSize;
        }
        hashTable[indexOne] = s;
        currentSize++;
    }
    if(loadFactor()>0.67){
        HashTable hashT = HashTable(tSize);
        for(int i =0; i<tSize; i++){
            if(hashTable[i] != ""){
                hashT.insert(hashTable[i]);
            }
            *this = hashT;
        }
    }
}

//returns true if string parameter is found.
bool HashTable::find(string s) const
{
    int indexOne = hashOne(s);
    int indexSecond = hashSecond(s);
    
    while(hashTable[indexOne] != "" && hashTable[indexOne] != s){
        indexOne = (indexOne + indexSecond)% tSize;
    }
    if(hashTable[indexOne] == s){
        return true;
    }
    return false;
}

// returns the number of items stored in the hashtable.
int HashTable::size() const
{
    return currentSize;
}

//returns the size of the hashtable.
int HashTable::maxSize() const
{
    return tSize;
}

// returns the load factor of the hashtable.
double HashTable::loadFactor() const
{
    double loadF = (1.0 * currentSize)/tSize;
    return loadF;
}

//helper function for copy constructor
void HashTable::copyHash(const HashTable& hashT)
{
    tSize = hashT.tSize; // creates the size equals to the parameter size.
    currentSize = hashT.currentSize; // number of items in the parameter.
    secondHashval = hashT.secondHashval;
    hashTable = new string[tSize]; //creates a new hashtable equal to the parameter size.
    
    for(int i =0; i<tSize; i++){
        hashTable[i] = hashT.hashTable[i]; // copies all the strings.
    }
}

//returns the first hash
int HashTable::hashOne(string s) const
{
    int temp = 0;
    
    for(int i = 0; i<s.length(); i++){
        temp = temp + (s[i]-96) * pow(32.0,1.0*(s.length()-1-i));
        temp = temp % tSize;
    }
    
    return temp;
}

//returns second hash
int HashTable::hashSecond(string s) const
{
    int indexOne = hashOne(s);
    int indexSecond = secondHashval - (indexOne% secondHashval);
    
    return indexSecond;
}

//checks if the parameter is prime and returns true if it is.
bool HashTable::checkIfPrime(int n) const
{
    if(n<2){
        return false;
    }
    bool isPrime = true;
    for(int i =2; i< n/2; i++){
        if(n%i == 0){
            isPrime = false;
            break;
        }
    }
    return isPrime;
}

//returns a prime number 
int HashTable::getMyPrime(int n) const
{
    while(true){
        if(checkIfPrime(n)){
            return n;
        }
        n++;
    }
}

