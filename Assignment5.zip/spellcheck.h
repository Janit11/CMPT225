#pragma once
#include"HashTable.h"
#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<stdexcept>
#include<iterator>
using namespace std;

vector<string> readFile(string filename)
{
    ifstream fin;
    fin.open(filename);
    
    if (fin.fail()){
        cerr<<"Failed to open file "<<filename<<endl;
    }
    
    istream_iterator<string> start(fin), end;
    vector<string> result(start, end);
    fin.close();
    
    return result;
}

//POST: if word is not in dict returns all strings in dict that can be made by deleting a single letter from word
vector<string> extraLetter(const HashTable & dict, string word)
{
    vector<string> vec;
    
    if(dict.find(word)){
        vec.push_back(word);
        return vec;
    }

    int i = 0;
    while( i < word.length()){
        string s = word;
        s.replace(i, 1, "");
        if(dict.find(s)){
            vec.push_back(s);
        }
        i++;
    }
    return vec;
}

//POST: if word is not in dict returns all strings in dict that can be made swapping any two adjacent letters in word
vector<string> transposition(const HashTable & dict, string word)
{
    vector<string> vec;
    
    if(dict.find(word)){
        vec.push_back(word);
        return vec;
    }
    
    int i = 0;
    while( i < word.length()-1){
        string s = word;
        swap(s[i], s[i+1]);
        if(dict.find(s)){
            vec.push_back(s);
        }
        i++;
    }
    return vec;
}

//POST: if word is not in dict returns all pairs of strings in dict that can be made by inserting a single space in word
vector<string> missingSpace(const HashTable & dict, string word)
{
    vector<string> vec;
    
    if(dict.find(word)){
        vec.push_back(word);
        return vec;
    }
    int i = 1;
    while( i < word.length()-1){
        string s = word;
        string ch = " ";
        s.insert(i, ch);
        
        if(dict.find(s.substr(0, i)) && dict.find(s.substr(i+1, word.length()))){
            vec.push_back(s);
        }
        i++;
    }
    return vec;
}

//POST: returns an alphabet
char getAlphabet (int i)
{
    char alphabet[26] = {'a','b','c','d','e','f','g','h','i','j','k','l','m',
                        'n','o','p','q','r','s','t','u','v','w','x','y','z'};
    
    return (alphabet[i]);
}

//POST: if word is not in dict returns all strings in dict that can be made by inserting any single letter of the alphabet at any position in word
vector<string> missingLetter(const HashTable & dict, string word)
{
    vector<string> vec;
    
    if(dict.find(word)){
        vec.push_back(word);
        return vec;
    }
    
    int i = 0;
    while( i <= word.length()){
        for(int j = 0 ; j < 26; j++){
            string s = word;
            s.insert(i, 1, getAlphabet(j));
            if(dict.find(s))
                vec.push_back(s);
        }
        i++;
    }
    return vec;
}

// POST: if word is not in dict returns all strings in dict  that can be made by changing any single letter of word to a different letter in the alphabet
vector<string> incorrectLetter(const HashTable & dict, string word)
{
    vector<string> vec;
    
    if(dict.find(word)){
        vec.push_back(word);
        return vec;
    }
    
    int i = 0;
    while( i < word.length()){
        for(int j = 0 ; j < 26; j++){
            string s = word;
            s[i] = getAlphabet(j);
            if(dict.find(s))
                vec.push_back(s);
        }
        i++;
    }
    return vec;
}

